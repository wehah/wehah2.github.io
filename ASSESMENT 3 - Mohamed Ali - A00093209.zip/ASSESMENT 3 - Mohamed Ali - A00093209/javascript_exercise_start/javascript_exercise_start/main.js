/* jQuery and javascript */















